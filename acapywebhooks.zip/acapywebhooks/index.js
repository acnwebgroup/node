'use strict';

const express = require('express');
const bodyParser = require('body-parser');
const app = express().use(bodyParser.json()); // creates http server

app.listen(8080, () => console.log('Webhook is listening'));

app.get('/', (req, res) => {
    return res.end(req.query.challenge);
});

app.post('/', (req, res) => {
    // print request body
    console.log(req.body);
    res.status(200).end()

    // return a text response
    const data = {
        responses: [
            {
                type: 'text',
                elements: ['Hi', 'Hello']
            }
        ]
    };

    res.json(data);
});